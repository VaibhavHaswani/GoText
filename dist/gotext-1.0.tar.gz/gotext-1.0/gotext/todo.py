''' TODO : 
1> add separate exception definitinos
2> write comments
3> add functionalities 
'''