from .gotext import GoDocument

VERSION = "1.0"