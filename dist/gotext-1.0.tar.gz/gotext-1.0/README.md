# GoText v1.0
GoText is a universal text extraction and preprocessing tool for python which supportss wide variety of document formats.
